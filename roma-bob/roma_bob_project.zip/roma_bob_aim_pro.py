import tkinter as tk
from tkinter import ttk
import json
from pathlib import Path

BG = "#050812"
CARD = "#10182b"
BLUE = "#087cff"
CYAN = "#00eaff"
RED = "#ff254f"
WHITE = "#f4f7ff"
MUTED = "#9aa9c4"

SAVE = Path.home() / ".roma_bob_settings.json"


class App:
    def __init__(self, root):
        self.root = root
        root.title("ROMA + BOB")
        root.geometry("440x820")
        root.minsize(420, 780)
        root.configure(bg=BG)

        self.assist = tk.BooleanVar(value=True)
        self.head = tk.IntVar(value=50)
        self.size = tk.IntVar(value=60)
        self.opacity = tk.IntVar(value=85)

        self.crosssize = tk.IntVar(value=60)
        self.crossop = tk.IntVar(value=100)

        self.color = "#00dfff"
        self.bubble = None
        self.control = None
        self.r_button = None
        self.r_button_canvas = None

        self.bubble_frozen = False
        self.bubble_drag = (0, 0)
        self.bubble_moved = False

        self.load()
        self.style()
        self.build()

        root.protocol("WM_DELETE_WINDOW", self.close)
        self.sync_floating_ui()

    def style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(
            "Blue.Horizontal.TScale",
            background=CARD,
            troughcolor="#26324d",
            sliderthickness=16
        )

    def label(self, p, t, n=10, c=WHITE, b=False, bg=None):
        return tk.Label(
            p,
            text=t,
            bg=bg or p.cget("bg"),
            fg=c,
            font=("Arial", n, "bold" if b else "normal")
        )

    def card(self, p):
        f = tk.Frame(
            p,
            bg=CARD,
            highlightbackground="#183b71",
            highlightthickness=1,
            bd=0
        )
        f.pack(fill="x", padx=12, pady=6)
        return f

    def btn(self, p, t, cmd, col="#102a56", fg=WHITE):
        return tk.Button(
            p,
            text=t,
            command=cmd,
            bg=col,
            fg=fg,
            activebackground="#0d4db4",
            activeforeground="white",
            relief="flat",
            bd=0,
            highlightthickness=0,
            font=("Arial", 9, "bold"),
            cursor="hand2",
            padx=7,
            pady=7
        )

    def slider(self, p, title, var, lo, hi):
        f = tk.Frame(p, bg=CARD)
        f.pack(fill="x", padx=12, pady=3)

        v = self.label(
            f, f"{title}: {var.get()}%",
            9, WHITE, bg=CARD
        )
        v.pack(anchor="w")

        ttk.Scale(
            f,
            from_=lo,
            to=hi,
            variable=var,
            style="Blue.Horizontal.TScale",
            command=lambda x: v.config(
                text=f"{title}: {int(float(x))}%"
            )
        ).pack(fill="x", pady=3)

    def build(self):
        self.label(
            self.root, "ROMA + BOB", 25, CYAN, True
        ).pack(pady=(12, 0))

        self.label(
            self.root,
            "HEADSHOT  •  DRAG  •  MAX",
            8, MUTED
        ).pack(pady=(0, 8))

        self.label(
            self.root,
            "ОПЦИЯ ПРИЦЕЛА", 8, BLUE, True, BG
        ).pack(anchor="center", pady=(0, 10))

        top = self.card(self.root)

        self.label(
            top,
            "FREE FIRE MAX | Панель настроек",
            11, WHITE, True
        ).pack(anchor="w", padx=12, pady=9)

        a = self.card(self.root)

        self.label(
            a, "НАСТРОЙКИ ПРИЦЕЛА",
            11, CYAN, True
        ).pack(anchor="w", padx=12, pady=5)

        self.canvas = tk.Canvas(
            a,
            width=130,
            height=95,
            bg="#080d1a",
            highlightthickness=0
        )
        self.canvas.pack()

        self.draw_cross()

        self.slider(
            a, "Размер прицела",
            self.crosssize, 10, 100
        )

        self.slider(
            a, "Прозрачность прицела",
            self.crossop, 10, 100
        )

        colors = tk.Frame(a, bg=CARD)
        colors.pack(fill="x", padx=8, pady=7)

        for c in [
            "#ff244e", "#ffe000", "#00e66b",
            "#00dfff", "#a500ff", "#ffffff",
            "#ff28a8", "#ff9638"
        ]:
            tk.Button(
                colors,
                bg=c,
                width=2,
                relief="flat",
                command=lambda x=c: self.set_color(x)
            ).pack(side="left", expand=True, padx=2)

        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", padx=12)

        self.btn(
            row,
            "❄ Заморозить прицел",
            lambda: self.msg("Прицел заморожен (демо)")
        ).pack(side="left", expand=True, fill="x", padx=3)

        self.btn(
            row,
            "◉ Скрыть прицел",
            lambda: self.msg("Прицел скрыт (демо)")
        ).pack(side="left", expand=True, fill="x", padx=3)

        pr = self.card(self.root)

        self.label(
            pr, "ПРОФИЛИ ЧУВСТВИТЕЛЬНОСТИ",
            11, CYAN, True
        ).pack(anchor="w", padx=12, pady=6)

        grid = tk.Frame(pr, bg=CARD)
        grid.pack(fill="x", padx=6, pady=4)

        names = [
            "Headshot", "One Tap", "Drag Shot",
            "Rush", "Pro Player", "MAX DRAG"
        ]

        for i, name in enumerate(names):
            self.btn(
                grid,
                name,
                lambda n=name: self.profile(n),
                "#3a2a08" if name == "MAX DRAG" else "#10244a",
                "#ffe16b" if name == "MAX DRAG" else WHITE
            ).grid(
                row=i // 3,
                column=i % 3,
                sticky="ew",
                padx=3,
                pady=3
            )

        for i in range(3):
            grid.columnconfigure(i, weight=1)

        h = self.card(self.root)

        self.label(
            h, "КРАСНАЯ КНОПКА R",
            11, CYAN, True
        ).pack(anchor="w", padx=12, pady=5)

        self.slider(h, "Headshot (10–100)", self.head, 10, 100)
        self.slider(h, "Размер круглой кнопки", self.size, 20, 100)
        self.slider(h, "Прозрачность кнопки", self.opacity, 10, 100)

        st = self.card(self.root)

        tk.Checkbutton(
            st,
            text="AssistiveTouch / плавающая кнопка",
            variable=self.assist,
            command=self.toggle_assist,
            bg=CARD,
            fg=WHITE,
            selectcolor="#172b4b",
            activebackground=CARD,
            activeforeground=CYAN,
            font=("Arial", 10, "bold")
        ).pack(anchor="w", padx=10, pady=8)

        self.label(
            st,
            'Выключи переключатель — появится круглый прицел.',
            8, MUTED
        ).pack(anchor="w", padx=12, pady=(0, 8))

        r_row = tk.Frame(st, bg=CARD)
        r_row.pack(fill="x", padx=10, pady=(0, 8))

        self.btn(
            r_row,
            "R",
            self.toggle_r_button,
            "#b81d5c",
            "#fff5fa"
        ).pack(side="left", ipadx=10, ipady=6)

        self.label(
            r_row,
            " малиновая кнопка R для быстрого доступа",
            8, MUTED, bg=CARD
        ).pack(side="left", padx=(8, 0), anchor="w")

        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", padx=12, pady=6)

        self.btn(
            row, "СБРОС", self.reset, "#34205e"
        ).pack(side="left", expand=True, fill="x", padx=3)

        self.btn(
            row, "СОХРАНИТЬ",
            lambda: self.save(True),
            "#075bd5"
        ).pack(side="left", expand=True, fill="x", padx=3)

        self.status = self.label(
            self.root, "Готово", 8, MUTED
        )
        self.status.pack()

        self.label(
            self.root,
            "Демо-интерфейс: не изменяет игровые файлы.",
            7, MUTED
        ).pack(pady=5)

    def draw_cross(self):
        if not hasattr(self, "canvas"):
            return

        c = self.canvas
        c.delete("all")

        x, y = 65, 47
        r = max(10, self.crosssize.get() * 0.38)

        c.create_oval(
            x-r, y-r, x+r, y+r,
            outline=self.color,
            width=3
        )

        c.create_line(
            x, y-r-9, x, y-r+8,
            fill=RED, width=3
        )

        c.create_line(
            x, y+r-8, x, y+r+9,
            fill="#ffe500", width=3
        )

        c.create_line(
            x-r-9, y, x-r+8, y,
            fill="#ff315a", width=3
        )

        c.create_line(
            x+r-8, y, x+r+9, y,
            fill=CYAN, width=3
        )

        c.create_oval(
            x-4, y-4, x+4, y+4,
            fill="white", outline=""
        )

    def set_color(self, c):
        self.color = c
        self.draw_cross()

    def msg(self, t):
        self.status.config(text=t)

    def profile(self, n):
        self.head.set(
            100 if n == "MAX DRAG"
            else 75 if n == "Headshot"
            else 60
        )
        self.msg("Профиль: " + n)
        self.save(False)

    def sync_floating_ui(self):
        if self.assist.get():
            self.hide_r_button()
            self.show_bubble()
            self.msg("AssistiveTouch активен")
        else:
            self.hide_bubble()
            self.show_r_button()
            self.msg("Круглая красная кнопка активна")

    def toggle_assist(self):
        self.save(False)
        self.sync_floating_ui()

    def toggle_r_button(self):
        if self.r_button and self.r_button.winfo_exists():
            self.hide_r_button()
            self.assist.set(False)
            self.msg("Круглая кнопка скрыта")
            self.save(False)
            return

        self.assist.set(False)
        self.show_r_button()
        self.msg("Кнопка R активна")
        self.save(False)

    def show_r_button(self):
        if self.r_button and self.r_button.winfo_exists():
            self.r_button.deiconify()
            return

        self.r_button = tk.Toplevel(self.root)
        self.r_button.overrideredirect(True)
        self.r_button.attributes("-topmost", True)

        d = max(34, min(72, int(self.size.get()) + 12))
        self.r_button.geometry(f"{d}x{d}+28+360")
        self.r_button.configure(bg=BG)

        self.r_button_canvas = tk.Canvas(
            self.r_button,
            width=d,
            height=d,
            bg=BG,
            highlightthickness=0
        )
        self.r_button_canvas.pack(fill="both", expand=True)

        self.draw_r_button()

        for widget in (self.r_button, self.r_button_canvas):
            widget.bind("<ButtonPress-1>", self.drag_start_r)
            widget.bind("<B1-Motion>", self.drag_move_r)
            widget.bind("<ButtonRelease-1>", self.r_button_click)

    def draw_r_button(self):
        if not self.r_button or not self.r_button.winfo_exists():
            return

        d = max(34, min(72, int(self.size.get()) + 12))
        self.r_button.geometry(
            f"{d}x{d}+{self.r_button.winfo_x()}+{self.r_button.winfo_y()}"
        )

        c = self.r_button_canvas
        c.config(width=d, height=d)
        c.delete("all")

        cx = cy = d / 2
        r = d * 0.42
        c.create_oval(
            cx-r, cy-r,
            cx+r, cy+r,
            fill="#ff2b5d",
            outline="#ff9ab1",
            width=max(2, int(d * 0.12))
        )
        c.create_text(
            cx, cy,
            text="R",
            fill="white",
            font=("Arial", max(14, int(d * 0.42)), "bold")
        )

    def drag_start_r(self, e):
        self.bubble_drag = (
            e.x_root-self.r_button.winfo_x(),
            e.y_root-self.r_button.winfo_y()
        )
        self.bubble_moved = False

    def drag_move_r(self, e):
        if self.bubble_frozen:
            return
        x = e.x_root-self.bubble_drag[0]
        y = e.y_root-self.bubble_drag[1]
        if abs(x-self.r_button.winfo_x()) + abs(y-self.r_button.winfo_y()) > 3:
            self.bubble_moved = True
        self.r_button.geometry(f"+{x}+{y}")

    def r_button_click(self, e):
        if not self.bubble_moved:
            self.open_control()

    def hide_r_button(self):
        if self.r_button and self.r_button.winfo_exists():
            self.r_button.destroy()
        self.r_button = None
        self.r_button_canvas = None

    def show_bubble(self):
        if self.bubble and self.bubble.winfo_exists():
            self.bubble.deiconify()
            return

        self.bubble = tk.Toplevel(self.root)
        self.bubble.overrideredirect(True)
        self.bubble.attributes("-topmost", True)

        d = max(64, min(140, int(self.size.get()) + 24))

        self.bubble.geometry(f"{d}x{d}+20+180")
        self.bubble.configure(bg=BG)

        self.bubble_canvas = tk.Canvas(
            self.bubble,
            width=d,
            height=d,
            bg=BG,
            highlightthickness=0
        )
        self.bubble_canvas.pack(fill="both", expand=True)

        self.draw_floating_crosshair()

        for widget in (self.bubble, self.bubble_canvas):
            widget.bind("<ButtonPress-1>", self.drag_start)
            widget.bind("<B1-Motion>", self.drag_move)
            widget.bind("<ButtonRelease-1>", self.bubble_click)

    def draw_floating_crosshair(self):
        if not self.bubble or not self.bubble.winfo_exists():
            return

        d = max(64, min(140, int(self.size.get()) + 24))

        self.bubble.geometry(
            f"{d}x{d}+{self.bubble.winfo_x()}+{self.bubble.winfo_y()}"
        )

        c = self.bubble_canvas
        c.config(width=d, height=d)
        c.delete("all")

        cx = cy = d / 2
        radius = d * 0.36

        c.create_oval(
            cx-radius, cy-radius,
            cx+radius, cy+radius,
            outline="#168cff",
            width=max(2, int(d/24))
        )

        c.create_arc(
            cx-radius, cy-radius,
            cx+radius, cy+radius,
            start=110,
            extent=160,
            style="arc",
            outline=RED,
            width=max(3, int(d/20))
        )

        tick = max(7, d * 0.15)

        for x1, y1, x2, y2 in [
            (cx, cy-radius-tick, cx, cy-radius+tick/2),
            (cx, cy+radius-tick/2, cx, cy+radius+tick),
            (cx-radius-tick, cy, cx-radius+tick/2, cy),
            (cx+radius-tick/2, cy, cx+radius+tick, cy)
        ]:
            c.create_line(
                x1, y1, x2, y2,
                fill="#eaf8ff",
                width=max(2, int(d/28))
            )

        dot = max(3, d * 0.055)

        c.create_oval(
            cx-dot, cy-dot,
            cx+dot, cy+dot,
            fill=RED,
            outline="#ffffff",
            width=1
        )

    def drag_start(self, e):
        self.bubble_drag = (
            e.x_root-self.bubble.winfo_x(),
            e.y_root-self.bubble.winfo_y()
        )
        self.bubble_moved = False

    def drag_move(self, e):
        if self.bubble_frozen:
            return

        x = e.x_root-self.bubble_drag[0]
        y = e.y_root-self.bubble_drag[1]

        if abs(x-self.bubble.winfo_x()) + abs(y-self.bubble.winfo_y()) > 3:
            self.bubble_moved = True

        self.bubble.geometry(f"+{x}+{y}")

    def bubble_click(self, e):
        if not self.bubble_moved:
            self.open_control()

    def hide_bubble(self):
        if self.bubble and self.bubble.winfo_exists():
            self.bubble.destroy()

        self.bubble = None

        if self.control and self.control.winfo_exists():
            self.control.destroy()

        self.control = None

    def toggle_freeze(self):
        self.bubble_frozen = not self.bubble_frozen

        if self.freeze_button.winfo_exists():
            self.freeze_button.config(
                text="РАЗМОРОЗИТЬ ПОЗИЦИЮ"
                if self.bubble_frozen
                else "ЗАМОРОЗИТЬ ПОЗИЦИЮ",
                bg="#9b2442" if self.bubble_frozen else "#075bd5"
            )

        self.msg(
            "Положение зафиксировано"
            if self.bubble_frozen
            else "Перемещение снова доступно"
        )

    def open_control(self):
        if self.control and self.control.winfo_exists():
            self.control.lift()
            return

        w = tk.Toplevel(self.root)
        self.control = w
        w.title("ROMA + BOB")
        w.geometry("360x390")
        w.configure(bg=BG)
        w.attributes("-topmost", True)

        self.label(
            w, "ROMA + BOB", 19, CYAN, True, BG
        ).pack(pady=(13, 5))

        tk.Frame(w, bg=BLUE, height=2).pack(fill="x", padx=16)

        preview = tk.Canvas(
            w, width=170, height=170,
            bg=BG, highlightthickness=0
        )
        preview.pack(pady=6)

        cx = cy = 85
        r = max(34, min(70, int(self.size.get()) * 0.65))

        preview.create_oval(
            cx-r, cy-r, cx+r, cy+r,
            outline="#168cff", width=4
        )

        preview.create_arc(
            cx-r, cy-r, cx+r, cy+r,
            start=110, extent=160,
            style="arc", outline=RED, width=5
        )

        preview.create_line(
            cx, cy-r-12, cx, cy-r+8,
            fill="white", width=3
        )

        preview.create_line(
            cx, cy+r-8, cx, cy+r+12,
            fill="white", width=3
        )

        preview.create_line(
            cx-r-12, cy, cx-r+8, cy,
            fill=RED, width=3
        )

        preview.create_line(
            cx+r-8, cy, cx+r+12, cy,
            fill=CYAN, width=3
        )

        preview.create_oval(
            cx-6, cy-6, cx+6, cy+6,
            fill=RED, outline="white"
        )

        box = tk.Frame(w, bg=CARD)
        box.pack(fill="x", padx=15, pady=5)

        self.label(
            box,
            f"Headshot: {self.head.get()}% (10–100%)",
            10, WHITE, True, CARD
        ).pack(anchor="w", padx=10, pady=(9, 2))

        ttk.Scale(
            box, from_=10, to=100,
            variable=self.head,
            style="Blue.Horizontal.TScale"
        ).pack(fill="x", padx=10, pady=(0, 9))

        self.label(
            box,
            f"Размер круглой кнопки: {self.size.get()}%",
            10, WHITE, True, CARD
        ).pack(anchor="w", padx=10, pady=(3, 2))

        ttk.Scale(
            box, from_=20, to=100,
            variable=self.size,
            style="Blue.Horizontal.TScale",
            command=lambda _v: self.draw_floating_crosshair()
        ).pack(fill="x", padx=10, pady=(0, 9))

        self.freeze_button = self.btn(
            w,
            "РАЗМОРОЗИТЬ ПОЗИЦИЮ"
            if self.bubble_frozen
            else "ЗАМОРОЗИТЬ ПОЗИЦИЮ",
            self.toggle_freeze,
            "#9b2442" if self.bubble_frozen else "#075bd5"
        )

        self.freeze_button.pack(fill="x", padx=18, pady=(10, 5))

        self.btn(
            w, "ЗАКРЫТЬ", w.destroy, "#26324d"
        ).pack(fill="x", padx=18, pady=5)

    def reset(self):
        self.head.set(50)
        self.size.set(50)
        self.opacity.set(85)
        self.crosssize.set(60)
        self.crossop.set(100)
        self.color = "#00dfff"

        self.draw_cross()
        self.msg("Сброшено")
        self.save(False)

    def save(self, announce=False):
        d = {
            "assist": self.assist.get(),
            "headshot": self.head.get(),
            "size": self.size.get(),
            "opacity": self.opacity.get(),
            "crosssize": self.crosssize.get(),
            "crossop": self.crossop.get(),
            "color": self.color,
            "bubble_frozen": self.bubble_frozen
        }

        try:
            SAVE.write_text(
                json.dumps(d),
                encoding="utf-8"
            )
        except OSError:
            pass

        if announce and hasattr(self, "status"):
            self.msg("Настройки сохранены")

    def load(self):
        try:
            d = json.loads(SAVE.read_text(encoding="utf-8"))

            self.assist.set(d.get("assist", True))
            self.head.set(d.get("headshot", 50))
            self.size.set(d.get("size", 50))
            self.opacity.set(d.get("opacity", 85))
            self.crosssize.set(d.get("crosssize", 60))
            self.crossop.set(d.get("crossop", 100))
            self.color = d.get("color", "#00dfff")
            self.bubble_frozen = bool(d.get("bubble_frozen", False))

        except (OSError, ValueError, TypeError):
            pass

    def close(self):
        self.save()
        self.hide_bubble()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()